
import './App.css';
import Box from './Box';

function App() {
  return (
    <div >
    <Box />
    
     
    </div>
  );
}

export default App;
